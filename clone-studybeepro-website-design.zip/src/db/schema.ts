import { integer, pgTable, text } from "drizzle-orm/pg-core";

export const batches = pgTable("batches", {
  id: integer("id").primaryKey(),
  title: text("title").notNull(),
  thumbnail: text("thumbnail").notNull(),
  section: text("section").notNull().default("new"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export type BatchRecord = typeof batches.$inferSelect;
