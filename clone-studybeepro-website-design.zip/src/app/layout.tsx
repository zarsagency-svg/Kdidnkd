import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

const logoUrl = "https://i.ibb.co/yF4mhNPB/f493d534-fbf8-4b31-b741-83b343f8a9e1.jpg";

export const metadata: Metadata = {
  title: "StudyBee 🐝 | Premium Batches",
  description: "Explore StudyBee premium batches and free learning content.",
  icons: { icon: logoUrl },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Syne:wght@600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="relative flex min-h-screen flex-col pb-12 font-sans">{children}</body>
    </html>
  );
}
