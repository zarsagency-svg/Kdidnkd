import type { Metadata } from "next";
import { SecureLogin } from "@/components/secure-login";

export const metadata: Metadata = { title: "StudyBee 🐝 | Secure Login" };

export default function LoginPage() {
  return <SecureLogin />;
}
