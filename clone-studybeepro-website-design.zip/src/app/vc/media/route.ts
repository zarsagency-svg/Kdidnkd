import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const incoming = new URL(request.url).searchParams;
  const courseId = incoming.get("course_id");
  const contentId = incoming.get("content_id");
  if (!courseId || !contentId || !/^\d+$/.test(courseId) || !/^\d+$/.test(contentId)) {
    return NextResponse.json({ error: "Invalid media query" }, { status: 400 });
  }
  try {
    const response = await fetch(
      `https://nt.studybeepro.site/vc/media?course_id=${courseId}&content_id=${contentId}`,
      { cache: "no-store", headers: { Accept: "application/json" }, signal: AbortSignal.timeout(20000) },
    );
    const data = (await response.json()) as unknown;
    return NextResponse.json(data, { status: response.status, headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Media details request failed:", error);
    return NextResponse.json({ error: "Media source unavailable" }, { status: 502 });
  }
}
