import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[A-Za-z0-9_-]+$/.test(id)) return NextResponse.json({ error: "Invalid media id" }, { status: 400 });
  try {
    const response = await fetch(`https://nt.studybeepro.site/vc/${encodeURIComponent(id)}`, {
      cache: "no-store",
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(20000),
    });
    const data = (await response.json()) as unknown;
    return NextResponse.json(data, { status: response.status, headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Secure media request failed:", error);
    return NextResponse.json({ error: "Media source unavailable" }, { status: 502 });
  }
}
