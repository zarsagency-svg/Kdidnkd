import { StudyBeeApp } from "@/components/study-bee-app";

export const dynamic = "force-dynamic";

export default function LivePage() {
  return <StudyBeeApp />;
}
