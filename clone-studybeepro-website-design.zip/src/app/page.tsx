import { StudyBeeApp } from "@/components/study-bee-app";

export default function HomePage() {
  return <StudyBeeApp />;
}
