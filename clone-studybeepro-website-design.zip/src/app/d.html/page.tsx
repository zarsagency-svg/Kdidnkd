import type { Metadata } from "next";
import { MediaPlayer } from "@/components/media-player";

export const metadata: Metadata = { title: "Download Media | StudyBee" };

export default async function DownloadPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const value = (key: string) => {
    const param = params[key];
    return Array.isArray(param) ? param[0] || "" : param || "";
  };
  return (
    <MediaPlayer
      courseId={value("courseId")}
      contentId={value("contentId")}
      vdcId={value("vdc_id")}
      youtubeUrl={value("yt_url")}
      downloadMode
    />
  );
}
