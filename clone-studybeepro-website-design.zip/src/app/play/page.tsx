import type { Metadata } from "next";

export { default } from "../player.html/page";
export const metadata: Metadata = { title: "Premium Player | StudyBee" };
