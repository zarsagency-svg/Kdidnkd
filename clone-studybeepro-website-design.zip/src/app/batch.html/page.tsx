import type { Metadata } from "next";
import { CourseBrowser } from "@/components/course-browser";
import { getBatch } from "@/lib/batches";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "StudyBee - Course Content",
};

export default async function BatchDetailPage({
  searchParams,
}: {
  searchParams: Promise<{ id?: string | string[] }>;
}) {
  const params = await searchParams;
  const rawId = Array.isArray(params.id) ? params.id[0] : params.id;
  const courseId = rawId && /^\d+$/.test(rawId) ? rawId : "0";
  const initialBatch = courseId === "0" ? null : await getBatch(Number(courseId));
  return <CourseBrowser courseId={courseId} initialBatch={initialBatch} />;
}
