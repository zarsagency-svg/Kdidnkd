import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type AuthRequest = {
  action?: string;
  mobile?: string;
  otp?: string;
  device_id?: string;
};

export async function POST(request: Request) {
  let body: AuthRequest;
  try {
    body = (await request.json()) as AuthRequest;
  } catch {
    return NextResponse.json({ success: false, message: "Invalid request" }, { status: 400 });
  }

  const mobile = String(body.mobile || "").replace(/\D/g, "");
  const deviceId = String(body.device_id || "").slice(0, 128);
  if (!/^\d{10}$/.test(mobile) || !deviceId) {
    return NextResponse.json({ success: false, message: "Enter a valid 10-digit mobile number" }, { status: 400 });
  }

  const isCheckUser = body.action === "check_user";
  const isVerifyOtp = body.action === "verify_otp";
  if (!isCheckUser && !isVerifyOtp) {
    return NextResponse.json({ success: false, message: "Unsupported authentication action" }, { status: 400 });
  }
  const otp = String(body.otp || "").replace(/\D/g, "");
  if (isVerifyOtp && !/^\d{6}$/.test(otp)) {
    return NextResponse.json({ success: false, message: "Enter a valid 6-digit OTP" }, { status: 400 });
  }

  const upstreamBody = isCheckUser
    ? { action: "check_user", mobile, device_id: deviceId, mobile_otp_login: 1, otp: "" }
    : { action: "verify_otp", mobile, otp, signup_needed: "0", device_id: deviceId, mobile_otp_login: 1 };
  const upstream = isCheckUser
    ? "https://chutapi.smexfot.workers.dev"
    : "https://nt.studybeepro.site/api/api";

  try {
    const response = await fetch(upstream, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(upstreamBody),
      cache: "no-store",
      signal: AbortSignal.timeout(20000),
    });
    const data = (await response.json()) as unknown;
    return NextResponse.json(data, {
      status: response.status,
      headers: { "Cache-Control": "no-store, max-age=0" },
    });
  } catch (error) {
    console.error("Authentication request failed:", error);
    return NextResponse.json({ success: false, message: "Authentication service unavailable" }, { status: 502 });
  }
}
