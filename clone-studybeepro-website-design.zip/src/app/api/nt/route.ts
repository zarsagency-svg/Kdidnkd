import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const PRIMARY_URL = "https://nt.studybeepro.site/api/nt";
const FALLBACK_URL = "https://asmultiverse.site/ntx/";
const ALLOWED_PARAMS = new Set([
  "overview",
  "content",
  "folder",
  "live",
  "test",
  "test_instructions",
  "test_data",
  "submit_test",
  "video",
  "contentId",
  "courseId",
  "vdc_id",
  "yt_url",
]);

export async function GET(request: Request) {
  const incoming = new URL(request.url).searchParams;
  const params = new URLSearchParams();
  for (const [key, value] of incoming) {
    if (ALLOWED_PARAMS.has(key) && value.length <= 2048) params.set(key, value);
  }
  if ([...params.keys()].length === 0) {
    return NextResponse.json({ success: false, message: "Missing course query" }, { status: 400 });
  }

  const query = params.toString();
  const urls = [`${PRIMARY_URL}?${query}`, `${FALLBACK_URL}?${query}`];
  let lastError: unknown;

  for (const url of urls) {
    try {
      const authorization = request.headers.get("authorization");
      const response = await fetch(url, {
        cache: "no-store",
        headers: {
          Accept: "application/json",
          ...(authorization ? { Authorization: authorization } : {}),
        },
        signal: AbortSignal.timeout(20000),
      });
      if (!response.ok) throw new Error(`Course API returned ${response.status}`);
      const data = (await response.json()) as unknown;
      return NextResponse.json(data, { headers: { "Cache-Control": "no-store, max-age=0" } });
    } catch (error) {
      lastError = error;
    }
  }

  console.error("Course API unavailable:", lastError);
  return NextResponse.json(
    { success: false, message: "Unable to load course data" },
    { status: 502, headers: { "Cache-Control": "no-store, max-age=0" } },
  );
}
