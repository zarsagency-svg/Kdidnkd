import { NextResponse } from "next/server";
import { getBatches } from "@/lib/batches";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const batches = await getBatches();
    return NextResponse.json(
      { new: batches, old: [] },
      { headers: { "Cache-Control": "no-store, max-age=0" } },
    );
  } catch (error) {
    console.error("Error fetching batches:", error);
    return NextResponse.json({ error: "Failed to load batches" }, { status: 500 });
  }
}
