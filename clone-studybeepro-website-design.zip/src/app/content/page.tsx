import type { Metadata } from "next";

export { default } from "../batch.html/page";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "StudyBee - Course Content",
};
