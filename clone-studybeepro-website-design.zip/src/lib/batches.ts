import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { batches, type BatchRecord } from "@/db/schema";

export const BATCH_SEED = [
  { id: 249, title: "Science 12th - NIRBHAY PRO (26-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/3331290_125_Class%2012th%20Science%20Plus.png" },
  { id: 248, title: "Commerce 12th - NIRBHAY PRO (26-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/543706_125_Class%2012th%20Commerce%20Plus.png" },
  { id: 247, title: "Humanities 12th - NIRBHAY PRO (26-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/712403_125_Class%2012th%20Humanities%20Plus.png" },
  { id: 246, title: "Science 12th - NIRBHAY (26-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/5734268_125_Class%2012th%20Science.png" },
  { id: 245, title: "Humanities 12th - NIRBHAY (26-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/7973_125_Class%2012th%20Humanities_.png" },
  { id: 244, title: "Commerce 12th - NIRBHAY (26-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/6586353_125_Class%2012th%20Commerce.png" },
  { id: 238, title: "Commerce 11th - NIRBHAY (26-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/226781_125_Class%2011th%20Commerce-2.png" },
  { id: 237, title: "Science (PCMB) 11th - NIRBHAY (26-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/4186013_125_Class%2011th%20Science-2.png" },
  { id: 236, title: "Humanities 11th - NIRBHAY (26-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/5000243_125_Class%2011th%20Humanities_.png" },
  { id: 234, title: "CUET (Science)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/5179885_125_03.png" },
  { id: 233, title: "CUET (Humanities)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/946060_125_cuet%20human.png" },
  { id: 232, title: "CUET (Commerce)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/5314437_125_01%20%289%29.png" },
  { id: 227, title: "Sample Paper Solutions", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/5386302_125_ChatGPT%20Image%20Oct%204%2C%202026%2C%2008_35_37%20PM.png" },
  { id: 224, title: "Class 12th Commerce", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/5136890_125_Class%2012th%20Commerce.png" },
  { id: 223, title: "Class 11th Commerce", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/6969105_125_Class%2011th%20Commerce.png" },
  { id: 219, title: "Class 12th Science", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/6151754_125_Class%2012th%20Science.png" },
  { id: 218, title: "Class 12th Humanities", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/4863083_125_Class%2012th%20Humanities.png" },
  { id: 217, title: "Class 11th Science", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/4101801_125_Class%2011th%20Science.png" },
  { id: 216, title: "Class 11th Humanities", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/4938269_125_Class%2011th%20Humanities.png" },
  { id: 215, title: "Free Course - Class 10th", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/7697438_125_App%20Banners%20Class%2010th%20FREE%20Courses09.png" },
  { id: 214, title: "Free Course - Class 9th", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/867330_125_App%20Banners%20Class%209th%20FREE%20Courses09.png" },
  { id: 206, title: "Free : Class 8th Content", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/1414042_125_Class%208th%20Nirmann%20Prashant%20Sir%20Banners09.png" },
  { id: 197, title: "NIRMAAN : Class 7", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/1228199_125_Class%207th%20Nirmann%20Prashant%20Sir%20Banners09-01.png" },
  { id: 228, title: "NIRMAAN-Term-II-Class-7-lFoundation-Program", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/6967602_125_Class-7th-Nirmaan-Term-II-App-Banners09.jpg" },
  { id: 177, title: "NIRMAAN BATCH CLASS 8TH 2026-27", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/6956338_125_Nirbhay%20Batch%20Class%208th%20App%20Banners09.jpg" },
  { id: 193, title: "NIRMAAN 2.0 BATCH Class 8th", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/6292174_125_Nirmaan%202.0%20Batch%20Class%208th%20App%20Banners09.png" },
  { id: 229, title: "NIRMAAN Term II | Class 8 lFoundation Program", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/2612865_125_Class-8th-Nirmaan-Term-II-App-Banners09.jpg" },
  { id: 178, title: "AARAMBH 2.0 9th BATCH 26-27", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/4330317_125_9th%20aarambh%202.0%20banner%20app%202.jpg" },
  { id: 179, title: "AARAMBH 2.0 PLUS 9th BATCH 26-27", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/1219057_125_9th%20aarambh%202.0%20plus%20banner%20app.jpg" },
  { id: 176, title: "AARAMBH 2.0 10th BATCH 26-27", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/356423_125_10th%20aarambh%202.0%20banner%20app%202.jpg" },
  { id: 107, title: "Science (PCMB) 11th - PRARAMBH 2.0 ( 2026-27 )", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/7450443_125_Science%20Prarambh%202.0%20Batch%20Class%2011th%20App%20Banners.jpg" },
  { id: 108, title: "Commerce 11th - PRARAMBH 2.0 ( 2026-27 )", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/498047_125_Commerce%20Prarambh%202.0%20Batch%20Class%2011th%20App%20Banners.jpg" },
  { id: 109, title: "Humanities 11th - PRARAMBH 2.0 ( 2026-27 )", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/6568182_125_Humanites%20Prarambh%202.0%20Batch%20Class%2011th%20App%20Banners.jpg" },
  { id: 112, title: "Science (PCMB) 11th - PRARAMBH PLUS 2.0 ( 2026-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/5976277_125_Science%20Prarambh%202.0%20Plus%20Batch%20Class%2011th%20App%20Banners.jpg" },
  { id: 110, title: "Commerce 11th - PRARAMBH PLUS 2.0 ( 2026-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/5668039_125_Commerce%20Prarambh%202.0%20Plus%20Batch%20Class%2011th%20App%20Banners.jpg" },
  { id: 111, title: "Humanities 11th - PRARAMBH PLUS 2.0 ( 2026-27)", thumbnail: "https://dylnd2lqy6eys.cloudfront.net/1770981347/admin_v2/uploads/courses/thumbnail/5345603_125_Humanities%20Prarambh%202.0%20Plus%20Batch%20Class%2011th%20App%20Banners.jpg" },
] as const;

let databaseReady: Promise<void> | null = null;

async function prepareDatabase() {
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS batches (
      id integer PRIMARY KEY,
      title text NOT NULL,
      thumbnail text NOT NULL,
      section text NOT NULL DEFAULT 'new',
      sort_order integer NOT NULL DEFAULT 0
    )
  `);

  await db
    .insert(batches)
    .values(BATCH_SEED.map((batch, sortOrder) => ({ ...batch, section: "new", sortOrder })))
    .onConflictDoUpdate({
      target: batches.id,
      set: {
        title: sql`excluded.title`,
        thumbnail: sql`excluded.thumbnail`,
        section: sql`excluded.section`,
        sortOrder: sql`excluded.sort_order`,
      },
    });
}

async function ensureDatabase() {
  if (!databaseReady) {
    databaseReady = prepareDatabase().catch((error: unknown) => {
      databaseReady = null;
      throw error;
    });
  }
  await databaseReady;
}

export async function getBatches(): Promise<BatchRecord[]> {
  await ensureDatabase();
  return db.select().from(batches).orderBy(asc(batches.sortOrder));
}

export async function getBatch(id: number): Promise<BatchRecord | null> {
  await ensureDatabase();
  const result = await db.select().from(batches).where(eq(batches.id, id)).limit(1);
  return result[0] ?? null;
}
