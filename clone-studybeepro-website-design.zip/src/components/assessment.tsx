"use client";

import { AlertCircle, CheckCircle2, ClipboardList, Clock3, Loader2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

type TestInstructionData = {
  total_time?: string;
  test_instructions?: string;
};

type QuestionOption = {
  option_id?: string | number;
  id?: string | number;
  option?: string;
  option_text?: string;
  title?: string;
  text?: string;
};

type TestQuestion = {
  question_group_id: string | number;
  question?: string;
  question_title?: string;
  question_text?: string;
  question_type?: string | number;
  is_multiple?: number | boolean;
  options?: Array<QuestionOption | string>;
};

type TestData = {
  test_name?: string;
  total_time?: string;
  sections?: Array<{ time_limits?: string; questions?: TestQuestion[] }>;
};

type ApiPayload<T> = { success?: boolean; message?: string; data?: T };
type Phase = "instructions" | "exam" | "result";

function formatTimer(totalSeconds: number) {
  const hours = Math.floor(totalSeconds / 3600).toString().padStart(2, "0");
  const minutes = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, "0");
  const seconds = Math.floor(totalSeconds % 60).toString().padStart(2, "0");
  return `${hours}:${minutes}:${seconds}`;
}

export function Assessment({ test, onClose }: { test: { id: string; title: string }; onClose: () => void }) {
  const [phase, setPhase] = useState<Phase>("instructions");
  const [instructions, setInstructions] = useState("<p>No special instructions provided.</p>");
  const [durationSeconds, setDurationSeconds] = useState(0);
  const [instructionError, setInstructionError] = useState<string | null>(null);
  const [examLoading, setExamLoading] = useState(false);
  const [examName, setExamName] = useState(test.title);
  const [questions, setQuestions] = useState<TestQuestion[]>([]);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [responses, setResponses] = useState<Record<string, string[]>>({});
  const [remainingSeconds, setRemainingSeconds] = useState(0);
  const [showSubmitModal, setShowSubmitModal] = useState(false);

  useEffect(() => {
    let active = true;
    async function loadInstructions() {
      const token = localStorage.getItem("studybee_token");
      try {
        const response = await fetch(`/api/nt?test_instructions=${encodeURIComponent(test.id)}&_t=${Date.now()}`, {
          cache: "no-store",
          headers: token ? { Authorization: `Bearer ${token}` } : {},
        });
        const json = (await response.json()) as ApiPayload<TestInstructionData>;
        if (!response.ok || !json.success || !json.data) throw new Error(json.message || "Failed to load instructions");
        if (!active) return;
        const totalTime = Number.parseInt(json.data.total_time || "0", 10) || 0;
        setDurationSeconds(totalTime);
        setInstructions(json.data.test_instructions || "<p>No special instructions provided.</p>");
      } catch (error) {
        if (active) setInstructionError(error instanceof Error ? error.message : "Failed to load instructions");
      }
    }
    void loadInstructions();
    return () => {
      active = false;
    };
  }, [test.id]);

  useEffect(() => {
    if (phase !== "exam") return;
    const interval = setInterval(() => {
      setRemainingSeconds((seconds) => {
        if (seconds <= 1) {
          clearInterval(interval);
          setShowSubmitModal(true);
          return 0;
        }
        return seconds - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [phase]);

  const currentQuestion = questions[questionIndex];
  const answeredCount = useMemo(
    () => questions.filter((question) => (responses[String(question.question_group_id)] || []).length > 0).length,
    [questions, responses],
  );

  async function fetchTestDataAndStart() {
    setExamLoading(true);
    const token = localStorage.getItem("studybee_token");
    try {
      const response = await fetch(`/api/nt?test_data=${encodeURIComponent(test.id)}&_t=${Date.now()}`, {
        cache: "no-store",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      const json = (await response.json()) as ApiPayload<TestData>;
      if (!response.ok || !json.success || !json.data) throw new Error(json.message || "Failed to load test data");
      const section = json.data.sections?.[0];
      if (!section?.questions?.length) {
        window.alert("No questions found in this test.");
        return;
      }
      setQuestions(section.questions);
      setExamName(json.data.test_name || test.title);
      setRemainingSeconds(
        Number.parseInt(section.time_limits || "", 10) ||
          Number.parseInt(json.data.total_time || "", 10) ||
          durationSeconds ||
          3600,
      );
      setResponses(Object.fromEntries(section.questions.map((question) => [String(question.question_group_id), []])));
      setQuestionIndex(0);
      setPhase("exam");
    } catch (error) {
      window.alert(`Failed to load test data: ${error instanceof Error ? error.message : "Unknown error"}`);
    } finally {
      setExamLoading(false);
    }
  }

  function selectOption(optionId: string) {
    if (!currentQuestion) return;
    const key = String(currentQuestion.question_group_id);
    const multiple = currentQuestion.is_multiple === true || currentQuestion.is_multiple === 1 ||
      String(currentQuestion.question_type || "").toLowerCase().includes("multiple");
    setResponses((current) => {
      const selected = current[key] || [];
      const next = multiple
        ? selected.includes(optionId)
          ? selected.filter((id) => id !== optionId)
          : [...selected, optionId]
        : [optionId];
      return { ...current, [key]: next };
    });
  }

  function saveAndNext() {
    if (questionIndex >= questions.length - 1) {
      setShowSubmitModal(true);
      return;
    }
    setQuestionIndex((index) => index + 1);
  }

  if (phase === "result") {
    return (
      <div id="view-result" className="animate-pop-in mx-auto w-full max-w-[800px] flex-1 pt-4 pb-12">
        <div className="rounded-2xl border border-white/5 bg-[#121212] p-8 text-center md:p-12">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full border border-theme-green/20 bg-theme-green/10">
            <CheckCircle2 className="h-8 w-8 text-theme-green" />
          </div>
          <h2 className="mb-2 text-2xl font-bold text-white">Assessment Submitted</h2>
          <p className="mb-8 text-sm text-stone-400">Your responses for {examName} have been recorded for this session.</p>
          <div className="mx-auto mb-8 grid max-w-md grid-cols-2 gap-4">
            <div className="rounded-xl border border-white/5 bg-white/5 p-5">
              <div className="text-2xl font-bold text-theme-yellow">{answeredCount}</div>
              <div className="mt-1 text-xs text-stone-400">Answered</div>
            </div>
            <div className="rounded-xl border border-white/5 bg-white/5 p-5">
              <div className="text-2xl font-bold text-white">{questions.length - answeredCount}</div>
              <div className="mt-1 text-xs text-stone-400">Unanswered</div>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="btn-click-effect rounded-lg bg-theme-yellow px-6 py-2.5 text-sm font-bold text-black transition-colors hover:bg-yellow-400"
          >
            Back to Content
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      {phase === "instructions" && (
        <div id="view-instructions" className="pb-safe animate-pop-in mx-auto flex w-full max-w-[800px] flex-1 flex-col">
          <div className="flex flex-1 flex-col rounded-2xl border border-white/5 bg-[#121212] p-6 md:p-8">
            <div className="mb-6 flex items-center gap-4 border-b border-white/5 pb-6">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-white/5">
                <ClipboardList className="h-6 w-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl leading-tight font-bold text-white">{test.title}</h2>
                <p className="mt-1 flex items-center gap-1 text-sm text-stone-400">
                  <Clock3 className="h-3.5 w-3.5" /> {Math.floor(durationSeconds / 60)} Mins Duration
                </p>
              </div>
            </div>
            <h3 className="mb-3 text-lg font-semibold text-white">Instructions</h3>
            {instructionError ? (
              <div className="flex flex-1 items-center gap-2 text-sm text-red-400">
                <AlertCircle className="h-4 w-4 shrink-0" /> Error: {instructionError}
              </div>
            ) : (
              <div
                className="course-description max-w-none flex-1 space-y-3 overflow-y-auto pr-2 text-sm text-gray-300"
                dangerouslySetInnerHTML={{ __html: instructions }}
              />
            )}
            <div className="mt-8 flex w-full flex-col justify-end gap-3 border-t border-white/5 pt-6 sm:flex-row">
              <button
                type="button"
                onClick={onClose}
                className="btn-click-effect rounded-lg bg-white/5 px-6 py-2.5 text-sm font-medium text-white transition-colors hover:bg-white/10"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void fetchTestDataAndStart()}
                className="btn-click-effect rounded-lg bg-theme-yellow px-6 py-2.5 text-sm font-bold text-black transition-colors hover:bg-yellow-400"
              >
                Start Assessment
              </button>
            </div>
          </div>
        </div>
      )}

      {phase === "exam" && currentQuestion && (
        <div id="view-exam" className="pb-safe animate-pop-in mx-auto flex h-[85vh] w-full max-w-[800px] flex-1 flex-col pt-2">
          <div className="flex h-full flex-col overflow-hidden rounded-2xl border border-white/5 bg-[#121212]">
            <div className="flex shrink-0 items-center justify-between border-b border-white/5 bg-[#18181b] p-4">
              <h2 className="truncate pr-4 text-sm font-semibold text-gray-200 md:text-base">{examName}</h2>
              <div className="flex shrink-0 items-center gap-3">
                <div className="flex items-center gap-2 rounded border border-white/10 bg-black/50 px-3 py-1.5 font-mono text-sm text-white">
                  <Clock3 className="h-4 w-4 text-theme-yellow" /> {formatTimer(remainingSeconds)}
                </div>
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(true)}
                  className="btn-click-effect rounded bg-white/10 px-4 py-1.5 text-sm font-semibold text-white transition-colors hover:bg-white/20"
                >
                  Submit
                </button>
              </div>
            </div>

            <div className="question-html flex-1 overflow-y-auto bg-[#0a0a0a] p-5 md:p-8">
              <div className="mb-5 text-xs font-semibold text-stone-500">
                Question {questionIndex + 1} of {questions.length}
              </div>
              <div
                className="course-description mb-6 text-base leading-relaxed text-gray-200"
                dangerouslySetInnerHTML={{
                  __html: currentQuestion.question || currentQuestion.question_title || currentQuestion.question_text || "",
                }}
              />
              <div className="space-y-3">
                {(currentQuestion.options || []).map((option, optionIndex) => {
                  const data = typeof option === "string" ? { option } : option;
                  const optionId = String(data.option_id ?? data.id ?? optionIndex);
                  const optionHtml = data.option || data.option_text || data.title || data.text || "";
                  const selected = (responses[String(currentQuestion.question_group_id)] || []).includes(optionId);
                  return (
                    <label
                      key={optionId}
                      className={`flex cursor-pointer items-center rounded-lg border px-4 py-3.5 text-sm transition-all ${
                        selected
                          ? "border-theme-yellow bg-theme-yellow/5"
                          : "border-white/5 bg-[#18181b] hover:bg-[#27272a]"
                      }`}
                    >
                      <input
                        type={currentQuestion.is_multiple === true || currentQuestion.is_multiple === 1 || String(currentQuestion.question_type || "").toLowerCase().includes("multiple") ? "checkbox" : "radio"}
                        name={`question-${String(currentQuestion.question_group_id)}`}
                        checked={selected}
                        onChange={() => selectOption(optionId)}
                        className="sr-only"
                      />
                      <span className={`mr-3 flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full border-2 ${selected ? "border-theme-yellow" : "border-zinc-600"}`}>
                        {selected && <span className="h-2 w-2 rounded-full bg-theme-yellow" />}
                      </span>
                      <span dangerouslySetInnerHTML={{ __html: optionHtml }} />
                    </label>
                  );
                })}
              </div>
            </div>

            <div className="flex shrink-0 justify-between gap-3 border-t border-white/5 bg-[#18181b] p-4">
              <div className="flex w-1/2 gap-2">
                <button
                  type="button"
                  disabled={questionIndex === 0}
                  onClick={() => setQuestionIndex((index) => Math.max(0, index - 1))}
                  className="btn-click-effect rounded-lg bg-white/5 px-4 py-2.5 text-sm font-medium text-gray-300 transition-colors hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() => setResponses((current) => ({ ...current, [String(currentQuestion.question_group_id)]: [] }))}
                  className="btn-click-effect rounded-lg px-4 py-2.5 text-sm font-medium text-stone-400 transition-colors hover:text-white"
                >
                  Clear
                </button>
              </div>
              <div className="flex w-1/2 justify-end gap-2">
                <button
                  type="button"
                  onClick={saveAndNext}
                  className="btn-click-effect rounded-lg bg-theme-yellow px-6 py-2.5 text-sm font-bold text-black transition-colors hover:bg-yellow-400"
                >
                  Save & Next
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showSubmitModal && (
        <div id="submit-modal" className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="animate-modal-in w-full max-w-sm rounded-2xl border border-white/10 bg-[#18181b] p-6 text-center">
            <h3 className="mb-2 text-xl font-bold text-white">Submit Assessment</h3>
            <p className="mb-6 text-sm text-stone-400">Are you sure you want to submit? You cannot change answers after submission.</p>
            <div className="flex w-full justify-center gap-3">
              <button
                type="button"
                onClick={() => setShowSubmitModal(false)}
                className="btn-click-effect flex-1 rounded-lg bg-white/5 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-white/10"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  sessionStorage.setItem(
                    `studybee_assessment_${test.id}`,
                    JSON.stringify({ testId: test.id, testName: examName, responses, submittedAt: new Date().toISOString() }),
                  );
                  setShowSubmitModal(false);
                  setPhase("result");
                }}
                className="btn-click-effect flex-1 rounded-lg bg-theme-yellow px-4 py-2.5 text-sm font-bold text-black transition-colors hover:bg-yellow-400"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}

      {examLoading && (
        <div id="exam-loading-modal" className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black/90 backdrop-blur-md">
          <Loader2 className="mb-4 h-8 w-8 animate-spin text-theme-yellow" />
          <h2 className="text-sm font-semibold tracking-wide text-white">Fetching Questions...</h2>
        </div>
      )}
    </>
  );
}
