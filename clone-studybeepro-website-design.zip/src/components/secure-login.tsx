"use client";

import { ArrowRight, KeyRound, Loader2, ShieldCheck, Smartphone, Unlock } from "lucide-react";
import { useEffect, useState } from "react";

const LOGO_URL = "https://i.ibb.co/yF4mhNPB/f493d534-fbf8-4b31-b741-83b343f8a9e1.jpg";

type AuthResponse = {
  success?: boolean | number | string;
  message?: string;
  error?: string;
  data?: unknown;
  token?: string;
};

type AlertState = { type: "success" | "error"; text: string } | null;

function isSuccess(response: AuthResponse) {
  return response.success === true || response.success === 1 || response.success === "1" || response.success === "true";
}

function findToken(value: unknown, depth = 0): string | null {
  if (depth > 6 || value === null || typeof value !== "object") return null;
  if (Array.isArray(value)) {
    for (const entry of value) {
      const token = findToken(entry, depth + 1);
      if (token) return token;
    }
    return null;
  }
  const object = value as Record<string, unknown>;
  for (const key of ["token", "access_token", "auth_token", "jwt"]) {
    if (typeof object[key] === "string" && object[key].length > 10) return object[key];
  }
  for (const entry of Object.values(object)) {
    const token = findToken(entry, depth + 1);
    if (token) return token;
  }
  return null;
}

export function SecureLogin() {
  const [step, setStep] = useState<"mobile" | "otp">("mobile");
  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState("");
  const [deviceId, setDeviceId] = useState("");
  const [busy, setBusy] = useState(false);
  const [alert, setAlert] = useState<AlertState>(null);

  useEffect(() => {
    const existing = localStorage.getItem("studybee_device_id");
    if (existing) {
      setDeviceId(existing);
      return;
    }
    const generated = `web_${crypto.randomUUID()}`;
    localStorage.setItem("studybee_device_id", generated);
    setDeviceId(generated);
  }, []);

  async function sendAuthOtp(event?: React.FormEvent) {
    event?.preventDefault();
    const normalizedMobile = mobile.replace(/\D/g, "");
    if (!/^\d{10}$/.test(normalizedMobile)) {
      setAlert({ type: "error", text: "Please enter a valid 10-digit mobile number." });
      return;
    }
    if (!deviceId) return;
    setBusy(true);
    setAlert(null);
    try {
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "check_user", mobile: normalizedMobile, device_id: deviceId }),
      });
      const data = (await response.json()) as AuthResponse;
      if (!response.ok || !isSuccess(data)) throw new Error(data.message || data.error || "Failed to send OTP.");
      setMobile(normalizedMobile);
      setStep("otp");
      setAlert({ type: "success", text: data.message || "OTP sent successfully." });
    } catch (error) {
      setAlert({ type: "error", text: error instanceof Error ? error.message : "Failed to send OTP." });
    } finally {
      setBusy(false);
    }
  }

  async function verifyAuthOtp(event?: React.FormEvent) {
    event?.preventDefault();
    if (!/^\d{6}$/.test(otp)) {
      setAlert({ type: "error", text: "Please enter a valid 6-digit OTP." });
      return;
    }
    setBusy(true);
    setAlert(null);
    try {
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "verify_otp", mobile, otp, device_id: deviceId }),
      });
      const data = (await response.json()) as AuthResponse;
      if (!response.ok || !isSuccess(data)) throw new Error(data.message || data.error || "Invalid OTP. Please try again.");
      const token = findToken(data) || (typeof data.data === "string" && data.data.length > 20 ? data.data : null);
      if (!token) throw new Error("Login succeeded but no access token was returned.");
      localStorage.setItem("studybee_token", token);
      setAlert({ type: "success", text: "Login successful. Redirecting..." });
      window.setTimeout(() => { window.location.href = "/"; }, 500);
    } catch (error) {
      setAlert({ type: "error", text: error instanceof Error ? error.message : "Failed to verify OTP." });
    } finally {
      setBusy(false);
    }
  }

  function resetAuth() {
    setStep("mobile");
    setOtp("");
    setAlert(null);
    setBusy(false);
  }

  return (
    <>
      <nav className="nav-glass sticky top-0 z-40 h-[80px] w-full shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
        <div className="mx-auto flex h-full max-w-[90rem] items-center justify-center px-4 sm:justify-start sm:px-6">
          <div className="group flex cursor-pointer items-center gap-3">
            <div className="relative flex h-11 w-11 items-center justify-center">
              <div className="absolute inset-0 animate-pulse rounded-xl bg-theme-yellow/30 blur-md transition-all duration-500 group-hover:bg-theme-yellow/50 group-hover:blur-lg" />
              <div className="relative z-10 flex h-11 w-11 items-center justify-center rounded-xl border border-theme-yellow/50 bg-black shadow-[0_0_20px_rgba(250,204,21,0.3)]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={LOGO_URL} alt="Logo" className="h-7 w-7 rounded-md" />
              </div>
            </div>
            <h1 className="font-syne text-2xl font-black tracking-[0.1em] text-white drop-shadow-lg">
              STUDY<span className="bg-gradient-to-r from-theme-yellow to-theme-amber bg-clip-text text-transparent">BEE</span>
            </h1>
          </div>
        </div>
      </nav>

      <main className="relative z-10 mx-auto flex min-h-[calc(100vh-80px)] w-full max-w-md flex-1 items-center justify-center px-4 pb-12">
        <div className="modal-glass animate-modal-in relative z-10 w-full overflow-hidden rounded-3xl p-8">
          <div className="pointer-events-none absolute -top-20 -right-20 h-40 w-40 rounded-full bg-theme-yellow/20 blur-[50px]" />
          <div className="relative z-10 mb-8 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl border border-theme-yellow/30 bg-black shadow-[0_0_20px_rgba(250,204,21,0.2)]">
              <ShieldCheck className="h-8 w-8 text-theme-yellow" />
            </div>
            <h2 className="font-syne text-2xl font-black tracking-wide text-white">Secure Login</h2>
            <p className="mt-1 text-sm text-stone-400">
              {step === "mobile" ? "Enter mobile to access platform" : "Enter the OTP sent to your mobile"}
            </p>
          </div>

          {step === "mobile" ? (
            <form id="authStep1" className="relative z-10" onSubmit={(event) => void sendAuthOtp(event)}>
              <div className="relative mb-5">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4"><Smartphone className="h-5 w-5 text-stone-500" /></div>
                <input
                  type="number"
                  id="mobileInput"
                  inputMode="numeric"
                  autoComplete="tel"
                  value={mobile}
                  onChange={(event) => setMobile(event.target.value)}
                  placeholder="Mobile Number"
                  className="block w-full rounded-xl border border-white/10 bg-[#050505] py-4 pr-4 pl-12 font-bold text-white shadow-inner transition-all placeholder:text-stone-600 focus:border-theme-yellow/50 focus:ring-1 focus:ring-theme-yellow/50 focus:outline-none"
                />
              </div>
              <button
                id="sendOtpBtn"
                type="submit"
                disabled={busy || !deviceId}
                className="btn-click-effect flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-theme-yellow to-theme-amber py-4 text-sm font-black tracking-widest text-black uppercase transition-all hover:shadow-[0_0_20px_rgba(250,204,21,0.4)] disabled:opacity-70"
              >
                {busy ? <><Loader2 className="h-5 w-5 animate-spin" /> Sending...</> : <>Send OTP <ArrowRight className="h-4 w-4" /></>}
              </button>
            </form>
          ) : (
            <form id="authStep2" className="relative z-10" onSubmit={(event) => void verifyAuthOtp(event)}>
              <div className="relative mb-5">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4"><KeyRound className="h-5 w-5 text-stone-500" /></div>
                <input
                  type="number"
                  id="otpInput"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  value={otp}
                  onChange={(event) => setOtp(event.target.value)}
                  placeholder="Enter 6-digit OTP"
                  className="block w-full rounded-xl border border-white/10 bg-[#050505] py-4 pr-4 pl-12 text-center font-bold tracking-[0.2em] text-white shadow-inner transition-all placeholder:text-stone-600 focus:border-theme-yellow/50 focus:ring-1 focus:ring-theme-yellow/50 focus:outline-none"
                />
              </div>
              <button
                id="verifyOtpBtn"
                type="submit"
                disabled={busy}
                className="btn-click-effect flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-theme-yellow to-theme-amber py-4 text-sm font-black tracking-widest text-black uppercase transition-all hover:shadow-[0_0_20px_rgba(250,204,21,0.4)] disabled:opacity-70"
              >
                {busy ? <><Loader2 className="h-5 w-5 animate-spin" /> Verifying...</> : <>Verify & Proceed <Unlock className="h-4 w-4" /></>}
              </button>
              <button type="button" onClick={resetAuth} className="mt-5 w-full text-center text-xs font-bold tracking-wider text-stone-500 uppercase transition-colors hover:text-white">Change Mobile Number</button>
            </form>
          )}

          {alert && (
            <div className={`mt-4 rounded-lg border p-3 text-center text-xs font-bold ${alert.type === "success" ? "border-green-800 bg-green-950/70 text-green-400" : "border-red-800 bg-red-950/70 text-red-400"}`}>
              {alert.text}
            </div>
          )}
        </div>
      </main>
    </>
  );
}
