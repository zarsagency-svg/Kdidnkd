"use client";

import Hls from "hls.js";
import {
  AlertCircle,
  ArrowLeft,
  Check,
  ChevronLeft,
  ChevronRight,
  Download,
  Loader2,
  Maximize,
  MoreVertical,
  Pause,
  PictureInPicture,
  Play,
  RotateCcw,
  RotateCw,
  Settings,
  Volume2,
  VolumeX,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";

type JsonRecord = Record<string, unknown>;
type MediaSource = { url: string; token?: string; kind: "video" | "pdf" | "youtube" };
type Quality = { index: number; label: string };

function record(value: unknown): JsonRecord {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value as JsonRecord : {};
}

function findUrl(value: unknown, depth = 0): string | null {
  if (depth > 8 || value === null || value === undefined) return null;
  if (typeof value === "string" && /^https?:\/\//i.test(value) && /\.(m3u8|mp4|webm|pdf)(\?|$)/i.test(value)) return value;
  if (typeof value !== "object") return null;
  if (Array.isArray(value)) {
    for (const entry of value) {
      const found = findUrl(entry, depth + 1);
      if (found) return found;
    }
    return null;
  }
  const object = value as JsonRecord;
  for (const key of ["file_url", "stream_url", "video_url", "url"]) {
    const candidate = object[key];
    if (typeof candidate === "string" && /^https?:\/\//i.test(candidate)) return candidate;
  }
  for (const entry of Object.values(object)) {
    const found = findUrl(entry, depth + 1);
    if (found) return found;
  }
  return null;
}

function findToken(value: unknown, depth = 0): string | undefined {
  if (depth > 8 || value === null || typeof value !== "object") return undefined;
  if (Array.isArray(value)) {
    for (const entry of value) {
      const token = findToken(entry, depth + 1);
      if (token) return token;
    }
    return undefined;
  }
  const object = value as JsonRecord;
  if (typeof object.token === "string") return object.token;
  for (const entry of Object.values(object)) {
    const token = findToken(entry, depth + 1);
    if (token) return token;
  }
  return undefined;
}

function parseJson(value: unknown): unknown {
  if (typeof value !== "string") return value;
  try { return JSON.parse(value) as unknown; } catch { return value; }
}

function timeLabel(value: number) {
  if (!Number.isFinite(value) || value < 0) return "0:00";
  const hours = Math.floor(value / 3600);
  const minutes = Math.floor((value % 3600) / 60);
  const seconds = Math.floor(value % 60).toString().padStart(2, "0");
  return hours > 0 ? `${hours}:${minutes.toString().padStart(2, "0")}:${seconds}` : `${minutes}:${seconds}`;
}

export function MediaPlayer({
  courseId,
  contentId,
  vdcId,
  youtubeUrl,
  downloadMode = false,
}: {
  courseId: string;
  contentId: string;
  vdcId: string;
  youtubeUrl: string;
  downloadMode?: boolean;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const indicatorTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [source, setSource] = useState<MediaSource | null>(null);
  const [loading, setLoading] = useState(true);
  const [loaderMessage, setLoaderMessage] = useState("Resolving Source...");
  const [error, setError] = useState<string | null>(null);
  const [title, setTitle] = useState("StudyBee Media");
  const [playing, setPlaying] = useState(false);
  const [buffering, setBuffering] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [muted, setMuted] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsPanel, setSettingsPanel] = useState<"main" | "quality" | "speed">("main");
  const [notesOpen, setNotesOpen] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [qualities, setQualities] = useState<Quality[]>([]);
  const [quality, setQuality] = useState(-1);
  const [indicator, setIndicator] = useState<"play" | "pause" | "left" | "right" | null>(null);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = previousOverflow; };
  }, []);

  useEffect(() => {
    let active = true;
    async function resolveVdc(id: string) {
      setLoaderMessage("Unlocking Secure Video...");
      const response = await fetch(`/vc/${encodeURIComponent(id)}`, { cache: "no-store" });
      if (!response.ok) throw new Error("Video unavailable");
      const json = (await response.json()) as unknown;
      const url = findUrl(json);
      if (!url) throw new Error("Video unavailable");
      return { url, token: findToken(json) };
    }

    async function resolveSource() {
      setLoading(true);
      setError(null);
      try {
        if (youtubeUrl) {
          const match = youtubeUrl.match(/(?:v=|youtu\.be\/)([A-Za-z0-9_-]{6,})/);
          if (!match) throw new Error("Video unavailable");
          if (active) setSource({ url: `https://www.youtube.com/embed/${match[1]}?autoplay=1&rel=0`, kind: "youtube" });
          return;
        }
        if (vdcId && vdcId !== "null") {
          const stream = await resolveVdc(vdcId);
          if (active) setSource({ ...stream, kind: "video" });
          return;
        }
        if (!courseId || !contentId) throw new Error("Video unavailable");
        setLoaderMessage("Fetching Details...");
        const response = await fetch(`/vc/media?course_id=${encodeURIComponent(courseId)}&content_id=${encodeURIComponent(contentId)}`, { cache: "no-store" });
        if (!response.ok) throw new Error("Video unavailable");
        const json = parseJson(await response.json());
        const root = record(json);
        const content = record(parseJson(root.decryptedData ?? root.data ?? root));
        const contentTitle = content.title ?? content.name ?? content.content_title;
        if (active && typeof contentTitle === "string" && contentTitle.trim()) setTitle(contentTitle);
        if (content.is_drm === 1 && typeof content.vdc_id === "string") {
          setLoaderMessage("Resolving DRM...");
          const stream = await resolveVdc(content.vdc_id);
          if (active) setSource({ ...stream, kind: "video" });
          return;
        }
        const directFile = typeof content.file_url === "string" ? content.file_url : null;
        const url = directFile || findUrl(content) || findUrl(json);
        if (!url) throw new Error("Video unavailable");
        const fileType = Number(content.file_type || 0);
        const isPdf = fileType === 1 || /\.pdf(\?|$)/i.test(url);
        if (/youtube\.com|youtu\.be/i.test(url)) {
          const match = url.match(/(?:v=|youtu\.be\/)([A-Za-z0-9_-]{6,})/);
          if (match) {
            if (active) setSource({ url: `https://www.youtube.com/embed/${match[1]}?autoplay=1&rel=0`, kind: "youtube" });
            return;
          }
        }
        if (active) setSource({ url, token: findToken(json), kind: isPdf ? "pdf" : "video" });
      } catch (caught) {
        if (active) setError(caught instanceof Error ? caught.message : "Video unavailable");
      } finally {
        if (active) setLoading(false);
      }
    }
    void resolveSource();
    return () => { active = false; };
  }, [courseId, contentId, vdcId, youtubeUrl]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !source || source.kind !== "video") return;
    const mediaUrl = source.token && !source.url.includes("token=")
      ? `${source.url}${source.url.includes("?") ? "&" : "?"}token=${encodeURIComponent(source.token)}`
      : source.url;
    setQualities([]);
    setQuality(-1);
    if (Hls.isSupported() && /\.m3u8(\?|$)/i.test(source.url)) {
      const hls = new Hls({ enableWorker: true });
      hlsRef.current = hls;
      hls.loadSource(mediaUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setQualities(hls.levels.map((level, index) => ({ index, label: level.height ? `${level.height}p` : `${Math.round(level.bitrate / 1000)} kbps` })));
        void video.play().catch(() => setPlaying(false));
      });
      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (data.fatal) setError("Video unavailable");
      });
    } else {
      video.src = mediaUrl;
      video.load();
      void video.play().catch(() => setPlaying(false));
    }
    return () => {
      hlsRef.current?.destroy();
      hlsRef.current = null;
      video.pause();
    };
  }, [source]);

  const flashIndicator = useCallback((value: "play" | "pause" | "left" | "right") => {
    if (indicatorTimer.current) clearTimeout(indicatorTimer.current);
    setIndicator(value);
    indicatorTimer.current = setTimeout(() => setIndicator(null), 600);
  }, []);

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      void video.play().catch(() => undefined);
      flashIndicator("play");
    } else {
      video.pause();
      flashIndicator("pause");
    }
    setShowControls(true);
  }, [flashIndicator]);

  const skip = useCallback((seconds: number) => {
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = Math.max(0, Math.min(video.duration || Infinity, video.currentTime + seconds));
    flashIndicator(seconds < 0 ? "left" : "right");
    setShowControls(true);
  }, [flashIndicator]);

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if (event.code === "Space") { event.preventDefault(); togglePlay(); }
      if (event.code === "ArrowLeft") skip(-10);
      if (event.code === "ArrowRight") skip(10);
      if (event.key.toLowerCase() === "m" && videoRef.current) setMuted(!videoRef.current.muted);
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [skip, togglePlay]);

  useEffect(() => {
    if (!showControls || !playing || settingsOpen || notesOpen) return;
    const timer = setTimeout(() => setShowControls(false), 3000);
    return () => clearTimeout(timer);
  }, [showControls, playing, settingsOpen, notesOpen]);

  function chooseSpeed(value: number) {
    setSpeed(value);
    if (videoRef.current) videoRef.current.playbackRate = value;
    setSettingsPanel("main");
  }

  function chooseQuality(index: number) {
    setQuality(index);
    if (hlsRef.current) hlsRef.current.currentLevel = index;
    setSettingsPanel("main");
  }

  async function toggleFullscreen() {
    const container = document.getElementById("player-container");
    if (!container) return;
    if (document.fullscreenElement) await document.exitFullscreen();
    else await container.requestFullscreen();
  }

  async function togglePip() {
    const video = videoRef.current;
    if (!video) return;
    if (document.pictureInPictureElement) await document.exitPictureInPicture();
    else await video.requestPictureInPicture();
  }

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="media-player fixed inset-0 z-[200] h-dvh w-full bg-black text-white">
      {loading && (
        <div id="loader" className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black">
          <Loader2 className="mb-4 h-10 w-10 animate-spin text-theme-yellow" />
          <p className="animate-pulse text-sm font-medium text-stone-400">{loaderMessage}</p>
        </div>
      )}
      {error && !loading && (
        <div id="error-message" className="absolute inset-0 z-50 flex flex-col items-center justify-center gap-3 bg-black/90">
          <AlertCircle className="h-12 w-12 text-red-500" />
          <p className="px-4 text-center font-bold text-red-400">{error}</p>
          <button type="button" onClick={() => window.location.reload()} className="mt-2 rounded-xl bg-theme-yellow px-5 py-2 text-sm font-bold text-black active:scale-95">Retry</button>
        </div>
      )}
      {source && !error && (
        <div id="video-content" className="relative h-full w-full bg-black">
          <div className="video-container" id="player-container" onMouseMove={() => setShowControls(true)}>
            {source.kind === "video" && (
              <video
                ref={videoRef}
                id="video-player"
                playsInline
                muted={muted}
                onPlay={() => setPlaying(true)}
                onPause={() => setPlaying(false)}
                onTimeUpdate={(event) => setCurrentTime(event.currentTarget.currentTime)}
                onDurationChange={(event) => setDuration(event.currentTarget.duration)}
                onWaiting={() => setBuffering(true)}
                onPlaying={() => setBuffering(false)}
                onCanPlay={() => setBuffering(false)}
              />
            )}
            {source.kind !== "video" && <iframe id="yt-player" src={source.url} title={title} allow="autoplay; fullscreen; encrypted-media" allowFullScreen />}
            {buffering && source.kind === "video" && (
              <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
                <div className="h-14 w-14 animate-spin rounded-full border-4 border-theme-yellow/30 border-t-theme-yellow" />
              </div>
            )}
            {source.kind === "video" && (
              <>
                <div className="tap-zone tap-left" onClick={() => skip(-10)} />
                <div className="tap-zone tap-center" onClick={togglePlay} />
                <div className="tap-zone tap-right" onClick={() => skip(10)} />
                <div className={`skip-indicator skip-left ${indicator === "left" ? "show" : ""}`}><RotateCcw className="h-7 w-7" /><span className="text-lg">-10s</span></div>
                <div className={`skip-indicator skip-right ${indicator === "right" ? "show" : ""}`}><RotateCw className="h-7 w-7" /><span className="text-lg">+10s</span></div>
                <div className={`center-icon ${indicator === "play" ? "show" : ""}`}><Play className="ml-1 h-10 w-10 fill-current" /></div>
                <div className={`center-icon ${indicator === "pause" ? "show" : ""}`}><Pause className="h-10 w-10 fill-current" /></div>
              </>
            )}

            <div className={`controls-overlay ${showControls ? "" : "hide"}`}>
              <div className="top-bar flex items-center justify-between gap-4">
                <button type="button" aria-label="Back" onClick={() => window.history.back()} className="relative z-50 flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/10 text-white transition-all hover:bg-white/20 active:scale-90"><ArrowLeft className="h-5 w-5" /></button>
                <div className="flex-1 truncate text-base font-bold text-white drop-shadow-md sm:text-lg">{title}</div>
                {downloadMode && source.kind !== "youtube" && (
                  <a href={source.url} download target="_blank" rel="noopener noreferrer" className="flex h-10 items-center gap-2 rounded-full bg-theme-yellow px-4 text-xs font-bold text-black"><Download className="h-4 w-4" /> Download</a>
                )}
                <div className="relative">
                  <button type="button" aria-label="Details" onClick={() => setNotesOpen((open) => !open)} className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/10 text-white shadow-lg transition-all hover:bg-white/20 active:scale-90"><MoreVertical className="h-5 w-5" /></button>
                  {notesOpen && (
                    <div className="popup-menu menu-notes flex">
                      <span className="mb-1 border-b border-white/10 pb-1 text-[10px] font-bold tracking-wider text-stone-400 uppercase">Details</span>
                      <div className="mt-1 flex flex-col gap-2"><p className="py-1 text-xs text-stone-500">No extra data</p></div>
                    </div>
                  )}
                </div>
              </div>

              {source.kind === "video" && (
                <div className="bottom-bar">
                  <div className="mb-4 flex items-center gap-4">
                    <span className="w-12 text-right font-mono text-xs text-zinc-300 sm:text-sm">{timeLabel(currentTime)}</span>
                    <div className="group relative flex flex-1 items-center">
                      <input aria-label="Seek" type="range" value={progress} step="0.1" min="0" max="100" onChange={(event) => {
                        const video = videoRef.current;
                        if (video && duration) video.currentTime = (Number(event.target.value) / 100) * duration;
                      }} className="absolute inset-0 z-10 h-6 w-full cursor-pointer opacity-0" />
                      <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-white/20"><div className="absolute top-0 bottom-0 left-0 rounded-full bg-theme-yellow shadow-[0_0_10px_#FACC15]" style={{ width: `${progress}%` }} /></div>
                    </div>
                    <span className="w-12 font-mono text-xs text-zinc-300 sm:text-sm">{timeLabel(duration)}</span>
                  </div>
                  <div className="relative z-50 flex items-center justify-between">
                    <div className="flex items-center gap-4 sm:gap-6">
                      <button type="button" aria-label="Rewind 10 seconds" onClick={() => skip(-10)} className="text-white transition-colors hover:text-theme-yellow"><RotateCcw className="h-6 w-6 sm:h-7 sm:w-7" /></button>
                      <button type="button" aria-label={playing ? "Pause" : "Play"} onClick={togglePlay} className="flex h-12 w-12 items-center justify-center rounded-full bg-theme-yellow text-black shadow-[0_0_20px_rgba(250,204,21,0.4)] transition-all hover:scale-105 sm:h-14 sm:w-14">
                        {playing ? <Pause className="h-6 w-6 fill-current sm:h-7 sm:w-7" /> : <Play className="ml-1 h-6 w-6 fill-current sm:h-7 sm:w-7" />}
                      </button>
                      <button type="button" aria-label="Forward 10 seconds" onClick={() => skip(10)} className="text-white transition-colors hover:text-theme-yellow"><RotateCw className="h-6 w-6 sm:h-7 sm:w-7" /></button>
                      <div className="mx-2 hidden h-6 w-px bg-white/20 sm:block" />
                      <button type="button" aria-label={muted ? "Unmute" : "Mute"} onClick={() => setMuted((value) => !value)} className="hidden text-white transition-colors hover:text-theme-yellow sm:block">{muted ? <VolumeX className="h-6 w-6" /> : <Volume2 className="h-6 w-6" />}</button>
                    </div>
                    <div className="flex items-center gap-4 sm:gap-6">
                      <button type="button" aria-label="Picture in picture" onClick={() => void togglePip()} className="hidden text-white transition-colors hover:text-theme-yellow sm:block"><PictureInPicture className="h-6 w-6" /></button>
                      <div className="relative">
                        <button type="button" aria-label="Settings" onClick={() => { setSettingsOpen((open) => !open); setSettingsPanel("main"); }} className="text-white transition-colors hover:text-theme-yellow"><Settings className="h-6 w-6 sm:h-7 sm:w-7" /></button>
                        {settingsOpen && (
                          <div className="popup-menu menu-settings flex">
                            {settingsPanel === "main" && <div className="p-2">
                              <button type="button" onClick={() => setSettingsPanel("quality")} className="flex w-full items-center justify-between rounded-xl p-3 text-sm font-bold text-zinc-200 transition-colors hover:bg-white/10">Quality <span className="flex items-center gap-1 text-theme-yellow">{quality === -1 ? "Auto" : qualities.find((item) => item.index === quality)?.label || "Auto"}<ChevronRight className="h-4 w-4" /></span></button>
                              <button type="button" onClick={() => setSettingsPanel("speed")} className="flex w-full items-center justify-between rounded-xl p-3 text-sm font-bold text-zinc-200 transition-colors hover:bg-white/10">Speed <span className="flex items-center gap-1 text-theme-yellow">{speed}x<ChevronRight className="h-4 w-4" /></span></button>
                            </div>}
                            {settingsPanel === "quality" && <div className="p-2">
                              <button type="button" onClick={() => setSettingsPanel("main")} className="mb-2 flex w-full items-center gap-2 border-b border-white/10 p-3 text-sm font-bold text-zinc-400 hover:text-white"><ChevronLeft className="h-4 w-4" /> Back</button>
                              <div className="custom-scrollbar flex max-h-48 flex-col gap-1 overflow-y-auto pr-1">
                                <button type="button" onClick={() => chooseQuality(-1)} className="flex items-center justify-between rounded-lg p-2.5 text-left text-sm hover:bg-white/10">Auto {quality === -1 && <Check className="h-4 w-4 text-theme-yellow" />}</button>
                                {qualities.map((item) => <button type="button" key={item.index} onClick={() => chooseQuality(item.index)} className="flex items-center justify-between rounded-lg p-2.5 text-left text-sm hover:bg-white/10">{item.label}{quality === item.index && <Check className="h-4 w-4 text-theme-yellow" />}</button>)}
                              </div>
                            </div>}
                            {settingsPanel === "speed" && <div className="p-2">
                              <button type="button" onClick={() => setSettingsPanel("main")} className="mb-2 flex w-full items-center gap-2 border-b border-white/10 p-3 text-sm font-bold text-zinc-400 hover:text-white"><ChevronLeft className="h-4 w-4" /> Back</button>
                              <div className="custom-scrollbar max-h-48 overflow-y-auto pr-1">{[0.5, 0.75, 1, 1.25, 1.5, 2].map((value) => <button type="button" key={value} onClick={() => chooseSpeed(value)} className="flex w-full items-center justify-between rounded-lg p-2.5 text-left text-sm hover:bg-white/10">{value}x{speed === value && <Check className="h-4 w-4 text-theme-yellow" />}</button>)}</div>
                            </div>}
                          </div>
                        )}
                      </div>
                      <button type="button" aria-label="Fullscreen" onClick={() => void toggleFullscreen()} className="text-white transition-colors hover:text-theme-yellow"><Maximize className="h-6 w-6 sm:h-7 sm:w-7" /></button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
