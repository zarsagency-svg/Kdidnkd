"use client";

import Link from "next/link";
import {
  ArrowLeft,
  ChevronRight,
  Clock3,
  Download,
  FileText,
  Folder,
  FolderOpen,
  Info,
  ListChecks,
  Loader2,
  Play,
  Video,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import type { BatchRecord } from "@/db/schema";
import { Assessment } from "@/components/assessment";

const LOGO_URL = "https://i.ibb.co/yF4mhNPB/f493d534-fbf8-4b31-b741-83b343f8a9e1.jpg";
const FALLBACK_VIDEO_THUMBNAIL = "https://decicqog4ulhy.cloudfront.net/0/admin_v2/uploads/courses/thumbnail/2671188_1_logo.jpg";

type ContentCounts = {
  folders?: { total?: number };
  video?: { paid?: number; free?: number };
  pdf?: { paid?: number; free?: number };
  test?: { paid?: number; free?: number };
};

type CourseItemData = {
  thumbnail?: string | null;
  content_counts?: ContentCounts;
  duration?: number;
  created_at?: number;
  is_live?: number;
  video_type?: number;
  file_type?: number;
  vdc_id?: string | null;
};

export type CourseItem = {
  type: "folder" | "file" | "test";
  entity_id: string;
  title: string;
  data?: CourseItemData;
};

type CourseDetails = {
  id: number;
  title: string;
  description?: string;
  thumbnail?: string;
};

type OverviewResponse = {
  success?: boolean;
  data?: Array<{
    type: string;
    data?: Array<{ layout_type: string; layout_data?: CourseDetails[] }>;
  }>;
};

type FolderLocation = { id: string; title: string };
type VideoSelection = { contentId: string; vdcId: string; youtubeUrl: string };

function formatDuration(seconds?: number) {
  if (!seconds || Number.isNaN(seconds)) return "00:00";
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  const minuteString = minutes.toString().padStart(2, "0");
  const secondString = remainingSeconds.toString().padStart(2, "0");
  return hours > 0 ? `${hours}:${minuteString}:${secondString}` : `${minuteString}:${secondString}`;
}

function formatDate(unixTimestamp?: number) {
  if (!unixTimestamp) return "";
  return new Date(unixTimestamp * 1000).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export function CourseBrowser({ courseId, initialBatch }: { courseId: string; initialBatch: BatchRecord | null }) {
  const [course, setCourse] = useState<CourseDetails | null>(
    initialBatch ? { id: initialBatch.id, title: initialBatch.title, thumbnail: initialBatch.thumbnail } : null,
  );
  const [description, setDescription] = useState<string | null>(null);
  const [overviewLoading, setOverviewLoading] = useState(true);
  const [overviewError, setOverviewError] = useState(false);
  const [activeTab, setActiveTab] = useState<"overview" | "content">("overview");
  const [items, setItems] = useState<CourseItem[]>([]);
  const [contentLoading, setContentLoading] = useState(true);
  const [folderHistory, setFolderHistory] = useState<FolderLocation[]>([{ id: "0", title: "Course Content" }]);
  const [videoSelection, setVideoSelection] = useState<VideoSelection | null>(null);
  const [activeTest, setActiveTest] = useState<{ id: string; title: string } | null>(null);
  const requestNumber = useRef(0);

  useEffect(() => {
    let active = true;
    async function fetchCourseOverview() {
      try {
        const response = await fetch(`/api/nt?overview=${encodeURIComponent(courseId)}&_t=${Date.now()}`, {
          cache: "no-store",
        });
        if (!response.ok) throw new Error("Overview request failed");
        const json = (await response.json()) as OverviewResponse;
        const overviewTab = json.data?.find((entry) => entry.type === "overview");
        const detailsSection = overviewTab?.data?.find((layout) => layout.layout_type === "details");
        const details = detailsSection?.layout_data?.[0];
        if (!active) return;
        if (json.success && details) {
          setCourse(details);
          setDescription(details.description ? details.description : "<p>No description available.</p>");
        } else if (!initialBatch) {
          setDescription("<p>No description available.</p>");
        } else {
          setDescription("<p>No description available.</p>");
        }
      } catch (error) {
        console.error("Overview Fetch Error:", error);
        if (active) setOverviewError(true);
      } finally {
        if (active) setOverviewLoading(false);
      }
    }
    void fetchCourseOverview();
    return () => {
      active = false;
    };
  }, [courseId, initialBatch]);

  const fetchFolder = useCallback(async (folderId: string) => {
    const requestId = ++requestNumber.current;
    setContentLoading(true);
    try {
      const response = await fetch(
        `/api/nt?content=${encodeURIComponent(courseId)}&folder=${encodeURIComponent(folderId)}&_t=${Date.now()}`,
        { cache: "no-store" },
      );
      if (!response.ok) throw new Error("Content request failed");
      const json = (await response.json()) as { success?: boolean; data?: CourseItem[] };
      if (requestId !== requestNumber.current) return;
      setItems(json.success && Array.isArray(json.data) ? json.data : []);
    } catch (error) {
      console.error("Content Fetch Error:", error);
      if (requestId === requestNumber.current) setItems([]);
    } finally {
      if (requestId === requestNumber.current) setContentLoading(false);
    }
  }, [courseId]);

  useEffect(() => {
    void fetchFolder("0");
    return () => {
      requestNumber.current += 1;
    };
  }, [fetchFolder]);

  function openFolder(item: CourseItem) {
    const location = { id: item.entity_id, title: item.title };
    setFolderHistory((history) => [...history, location]);
    void fetchFolder(item.entity_id);
  }

  function goToFolder(index: number) {
    const location = folderHistory[index];
    if (!location || index === folderHistory.length - 1) return;
    setFolderHistory((history) => history.slice(0, index + 1));
    void fetchFolder(location.id);
  }

  function startAssessment(test: { id: string; title: string }) {
    if (!localStorage.getItem("studybee_token")) {
      window.alert("Please login to attempt this test.");
      window.location.href = "/login.html";
      return;
    }
    setActiveTest(test);
  }

  function videoUrl(selection: VideoSelection) {
    const params = new URLSearchParams({ courseId, contentId: selection.contentId });
    if (selection.vdcId) params.set("vdc_id", selection.vdcId);
    if (selection.youtubeUrl) params.set("yt_url", selection.youtubeUrl);
    return params.toString();
  }

  return (
    <div className="course-browser flex min-h-screen flex-1 flex-col text-[#f4f4f5]">
      <header className="nav-glass sticky top-0 z-50 flex shrink-0 items-center justify-between px-4 py-3">
        <div className="flex items-center gap-4 md:gap-6">
          <Link
            href="/"
            className="btn-click-effect flex items-center gap-2 text-sm font-semibold text-stone-400 transition-colors hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" /> <span className="hidden md:inline">Back</span>
          </Link>
          <Link href="/" className="flex items-center gap-3" aria-label="StudyBee home">
            <span className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-lg border border-white/10 bg-black md:h-9 md:w-9">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={LOGO_URL} alt="Logo" className="h-full w-full object-cover" />
            </span>
            <span className="font-syne text-lg font-bold tracking-wider text-white">
              STUDY<span className="text-theme-yellow">BEE</span>
            </span>
          </Link>
        </div>
        <div className="flex items-center gap-2 rounded-md border border-green-500/20 bg-green-500/10 px-3 py-1.5 text-[10px] font-semibold tracking-wide text-green-400 uppercase md:text-xs">
          <span className="h-1.5 w-1.5 rounded-full bg-green-400" /> Enrolled
        </div>
      </header>

      <main className="pb-safe relative z-10 mx-auto flex w-full max-w-[1400px] flex-1 flex-col overflow-y-auto p-4 md:p-6">
        {activeTest ? (
          <Assessment test={activeTest} onClose={() => setActiveTest(null)} />
        ) : (
          <div id="view-content" className="animate-pop-in flex w-full flex-1 flex-col pb-12">
            {course && (
              <div
                id="course-banner"
                className="relative mb-8 flex flex-col-reverse items-center justify-between gap-8 overflow-hidden rounded-2xl border border-white/5 bg-[#121212] p-6 shadow-xl md:flex-row md:p-8"
              >
                <div className="pointer-events-none absolute -top-32 -left-32 h-64 w-64 rounded-full bg-theme-yellow/10 blur-[100px]" />
                <div className="relative z-10 flex w-full flex-1 flex-col items-start gap-3">
                  <span className="rounded border border-theme-yellow/20 bg-theme-yellow/10 px-2 py-1 text-xs font-medium tracking-wider text-theme-yellow uppercase">
                    Premium Course
                  </span>
                  <h2 id="course-title" className="text-2xl leading-tight font-bold text-white md:text-4xl">
                    {course.title}
                  </h2>
                </div>
                {course.thumbnail && (
                  <div className="relative z-10 flex w-full shrink-0 justify-center md:w-auto md:justify-end">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      id="course-thumb"
                      src={course.thumbnail}
                      alt="Thumbnail"
                      className="aspect-[16/9] w-full max-w-[300px] rounded-xl border border-white/10 object-cover"
                    />
                  </div>
                )}
              </div>
            )}

            <div className="scrollbar-hide mb-6 flex w-full shrink-0 gap-6 overflow-x-auto border-b border-white/10 md:gap-8">
              <button
                id="tab-overview"
                type="button"
                onClick={() => setActiveTab("overview")}
                className={`btn-click-effect flex shrink-0 items-center gap-2 border-b-2 pb-3 text-sm font-semibold whitespace-nowrap transition-colors md:text-base ${
                  activeTab === "overview"
                    ? "border-theme-yellow text-theme-yellow"
                    : "border-transparent text-stone-400 hover:text-white"
                }`}
              >
                <Info className="h-4 w-4" /> Overview
              </button>
              <button
                id="tab-content"
                type="button"
                onClick={() => setActiveTab("content")}
                className={`btn-click-effect flex shrink-0 items-center gap-2 border-b-2 pb-3 text-sm font-semibold whitespace-nowrap transition-colors md:text-base ${
                  activeTab === "content"
                    ? "border-theme-yellow text-theme-yellow"
                    : "border-transparent text-stone-400 hover:text-white"
                }`}
              >
                <FolderOpen className="h-4 w-4" /> Content
              </button>
              <Link
                id="tab-live"
                href={`/live.html?id=${courseId}`}
                className="btn-click-effect flex shrink-0 items-center gap-2 border-b-2 border-transparent pb-3 text-sm font-semibold whitespace-nowrap text-stone-400 transition-colors hover:text-white md:text-base"
              >
                <Video className="h-4 w-4" /> Live Classes
              </Link>
            </div>

            {activeTab === "overview" && (
              <div id="section-overview">
                <div
                  id="course-desc-content"
                  className="course-description max-w-none rounded-xl border border-white/5 bg-[#121212] p-6 text-sm leading-relaxed text-gray-300 md:p-8 md:text-base"
                >
                  {overviewLoading ? (
                    <p className="animate-pulse">Loading description...</p>
                  ) : overviewError ? (
                    <p className="text-stone-400">Error loading description.</p>
                  ) : (
                    <div dangerouslySetInnerHTML={{ __html: description || "<p>No description available.</p>" }} />
                  )}
                </div>
              </div>
            )}

            {activeTab === "content" && (
              <div id="section-content" className="flex h-full flex-col">
                <div className="scrollbar-hide mb-5 flex items-center overflow-x-auto rounded-lg border border-white/5 bg-[#121212] p-3 whitespace-nowrap">
                  <div id="breadcrumbs" className="flex items-center px-1 text-xs font-medium text-stone-400 md:text-sm">
                    {folderHistory.map((location, index) => (
                      <span key={`${location.id}-${index}`} className="flex items-center">
                        {index > 0 && <ChevronRight className="mx-2 h-3.5 w-3.5 text-stone-600" />}
                        <button
                          type="button"
                          onClick={() => goToFolder(index)}
                          className={index === folderHistory.length - 1 ? "text-theme-yellow" : "hover:text-white"}
                        >
                          {location.title}
                        </button>
                      </span>
                    ))}
                  </div>
                </div>

                {contentLoading ? (
                  <div id="loader" className="flex flex-col items-center justify-center py-20">
                    <Loader2 className="mb-3 h-8 w-8 animate-spin text-theme-yellow" />
                    <p className="text-sm font-medium text-stone-400">Loading content...</p>
                  </div>
                ) : items.length > 0 ? (
                  <div
                    id="content-grid"
                    className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 md:gap-5 lg:grid-cols-5"
                  >
                    {items.map((item, index) => (
                      <CourseContentCard
                        key={`${item.type}-${item.entity_id}`}
                        item={item}
                        index={index}
                        onFolder={() => openFolder(item)}
                        onVideo={(selection) => setVideoSelection(selection)}
                        courseId={courseId}
                        onTest={() => startAssessment({ id: item.entity_id, title: item.title })}
                      />
                    ))}
                  </div>
                ) : (
                  <div id="empty-state" className="flex flex-col items-center justify-center py-20 text-center">
                    <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-white/5 bg-white/5">
                      <FolderOpen className="h-8 w-8 text-stone-500" />
                    </div>
                    <h3 className="mb-1 text-lg font-bold text-white">Folder is Empty</h3>
                    <p className="text-sm text-stone-400">No content available here yet.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>

      {videoSelection && (
        <div id="video-options-modal" className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="animate-modal-in w-full max-w-xs rounded-2xl border border-white/10 bg-[#18181b] p-6 text-center">
            <h3 className="mb-4 text-lg font-bold text-white">Video Options</h3>
            <div className="flex w-full flex-col gap-2.5">
              <Link
                id="btn-play-video"
                href={`/player.html?${videoUrl(videoSelection)}`}
                className="btn-click-effect flex w-full items-center justify-center gap-2 rounded-lg bg-theme-yellow px-4 py-2.5 text-sm font-semibold text-black transition-colors hover:bg-yellow-400"
              >
                <Play className="h-4 w-4 fill-current" /> Watch Now
              </Link>
              <Link
                id="btn-download-video"
                href={`/d.html?${videoUrl(videoSelection)}`}
                className="btn-click-effect flex w-full items-center justify-center gap-2 rounded-lg bg-white/5 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-white/10"
              >
                <Download className="h-4 w-4" /> Download
              </Link>
              <button
                type="button"
                onClick={() => setVideoSelection(null)}
                className="btn-click-effect mt-2 w-full rounded-lg px-4 py-2 text-sm font-medium text-stone-400 transition-colors hover:text-white"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function CourseContentCard({
  item,
  index,
  onFolder,
  onVideo,
  onTest,
  courseId,
}: {
  item: CourseItem;
  index: number;
  onFolder: () => void;
  onVideo: (selection: VideoSelection) => void;
  onTest: () => void;
  courseId: string;
}) {
  const delay = `${index * 30}ms`;

  if (item.type === "folder") {
    const counts = item.data?.content_counts || {};
    const badges: string[] = [];
    const folderCount = counts.folders?.total || 0;
    const videoCount = (counts.video?.paid || 0) + (counts.video?.free || 0);
    const pdfCount = (counts.pdf?.paid || 0) + (counts.pdf?.free || 0);
    const testCount = (counts.test?.paid || 0) + (counts.test?.free || 0);
    if (folderCount > 0) badges.push(`FOLDERS ${folderCount}`);
    if (videoCount > 0) badges.push(`VIDEO ${videoCount}`);
    if (pdfCount > 0) badges.push(`PDF ${pdfCount}`);
    if (testCount > 0) badges.push(`TEST ${testCount}`);

    return (
      <button
        type="button"
        onClick={onFolder}
        className="glass-card animate-pop-in btn-click-effect group flex h-[220px] cursor-pointer flex-col overflow-hidden rounded-[20px] text-left"
        style={{ animationDelay: delay }}
      >
        <div className="relative h-[125px] w-full shrink-0 overflow-hidden border-b border-white/5 bg-[#18181b]">
          {item.data?.thumbnail ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={item.data.thumbnail}
              alt=""
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          ) : (
            <span className="flex h-full w-full items-center justify-center bg-[#18181b]">
              <Folder className="h-10 w-10 fill-theme-yellow text-theme-yellow drop-shadow-[0_0_15px_rgba(250,204,21,0.3)]" />
            </span>
          )}
        </div>
        <div className="flex flex-1 flex-col justify-center bg-[#121212] p-3 transition-colors group-hover:bg-[#1a1a1a]">
          <h3 className="line-clamp-2 text-sm leading-snug font-medium text-white">{item.title}</h3>
          <div className="mt-2 text-[9px] font-bold tracking-wider text-stone-400 uppercase">
            {badges.length > 0
              ? badges.map((badge, badgeIndex) => (
                  <span key={badge} className={badgeIndex > 0 ? "ml-3" : ""}>{badge}</span>
                ))
              : "EMPTY"}
          </div>
        </div>
      </button>
    );
  }

  if (item.type === "test") {
    return (
      <div
        className="glass-card animate-pop-in col-span-full flex flex-col justify-between overflow-hidden rounded-[20px] border border-white/5 p-4 transition-all duration-200 hover:border-theme-yellow/30 sm:flex-row sm:items-center"
        style={{ animationDelay: delay }}
      >
        <div className="mb-4 flex items-start gap-4 sm:mb-0 sm:items-center">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border border-indigo-500/20 bg-indigo-500/10">
            <ListChecks className="h-7 w-7 text-indigo-400" />
          </div>
          <div>
            <div className="mb-1 flex items-center gap-2">
              <span className="rounded border border-indigo-500/20 bg-indigo-500/10 px-1.5 py-0.5 text-[9px] font-bold tracking-widest text-indigo-400 uppercase">
                MOCK TEST
              </span>
            </div>
            <h3 className="text-base font-medium text-white">{item.title}</h3>
          </div>
        </div>
        <button
          type="button"
          onClick={onTest}
          className="btn-click-effect w-full rounded-lg bg-white/10 px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-theme-yellow hover:text-black sm:w-auto"
        >
          Start Assessment
        </button>
      </div>
    );
  }

  const isVideo = item.data?.file_type === 2 || Number(item.data?.video_type || 0) > 0;
  const formattedDate = formatDate(item.data?.created_at);
  if (!isVideo) {
    const vdcId = item.data?.vdc_id || "";
    const params = new URLSearchParams({ courseId, contentId: item.entity_id });
    if (vdcId) params.set("vdc_id", vdcId);
    return (
      <Link
        href={`/player.html?${params.toString()}`}
        className="glass-card animate-pop-in btn-click-effect group flex h-[220px] cursor-pointer flex-col overflow-hidden rounded-[20px]"
        style={{ animationDelay: delay }}
      >
        <div className="relative flex h-[125px] w-full shrink-0 items-center justify-center border-b border-white/5 bg-[#18181b]">
          <FileText className="h-10 w-10 text-red-400 transition-transform group-hover:scale-110" />
          <div className="absolute top-2 left-2">
            <span className="rounded border border-red-500/20 bg-red-500/10 px-2 py-0.5 text-[10px] font-medium text-red-400">PDF</span>
          </div>
        </div>
        <div className="flex flex-1 flex-col justify-center bg-[#121212] p-3 transition-colors group-hover:bg-[#1a1a1a]">
          <h3 className="line-clamp-2 text-sm leading-snug font-medium text-gray-200">{item.title}</h3>
          {formattedDate && <div className="mt-2 text-[10px] font-medium tracking-wide text-stone-500">{formattedDate}</div>}
        </div>
      </Link>
    );
  }

  const thumbnail = item.data?.thumbnail?.trim() ? item.data.thumbnail : FALLBACK_VIDEO_THUMBNAIL;
  const durationRaw = item.data?.duration || 0;
  const duration = formatDuration(durationRaw);
  const isLive = item.data?.is_live === 1;
  const videoType = item.data?.video_type;
  const vdcId = item.data?.vdc_id || "";
  const isUpcoming = !isLive && durationRaw === 0 && videoType !== 4;
  const isYouTube = !vdcId && videoType === 1;
  let youtubeUrl = "";
  if (isYouTube && thumbnail.includes("i.ytimg.com/vi/")) {
    const parts = thumbnail.split("/vi/");
    const youtubeId = parts[1]?.split("/")[0];
    if (youtubeId) youtubeUrl = `https://www.youtube.com/watch?v=${youtubeId}`;
  }

  return (
    <button
      type="button"
      onClick={() => onVideo({ contentId: item.entity_id, vdcId, youtubeUrl })}
      className="glass-card animate-pop-in btn-click-effect group flex h-[220px] cursor-pointer flex-col overflow-hidden rounded-[20px] text-left"
      style={{ animationDelay: delay }}
    >
      <div className="relative h-[125px] w-full shrink-0 overflow-hidden border-b border-white/5 bg-black">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={thumbnail}
          alt={item.title}
          className="h-full w-full object-cover opacity-80 transition-all duration-300 group-hover:scale-105 group-hover:opacity-100"
        />
        <div className="absolute top-2 left-2">
          {isYouTube ? (
            <span className="flex items-center gap-1 rounded border border-red-500/20 bg-red-500/20 px-2 py-0.5 text-[10px] font-bold text-red-500">
              <Play className="h-3 w-3 fill-current" /> YOUTUBE
            </span>
          ) : isLive ? (
            <span className="flex items-center gap-1.5 rounded bg-red-500 px-2 py-0.5 text-[10px] font-bold text-white shadow-lg">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" /> LIVE
            </span>
          ) : isUpcoming ? (
            <span className="flex items-center gap-1 rounded border border-blue-500/20 bg-blue-500/20 px-2 py-0.5 text-[10px] font-bold text-blue-400">
              <Clock3 className="h-3 w-3" /> UPCOMING
            </span>
          ) : (
            <span className="flex items-center gap-1 rounded border border-white/10 bg-black/60 px-2 py-0.5 text-[10px] font-bold text-theme-yellow backdrop-blur-sm">
              <span className="h-1.5 w-1.5 rounded-full bg-theme-yellow" /> VIDEO
            </span>
          )}
        </div>
        <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 transition-opacity duration-200 group-hover:opacity-100">
          <span className="flex h-12 w-12 scale-75 items-center justify-center rounded-full border border-theme-yellow/50 bg-theme-yellow/90 pl-1 shadow-[0_0_15px_rgba(250,204,21,0.5)] backdrop-blur-sm transition-transform duration-300 group-hover:scale-100">
            <Play className="h-5 w-5 fill-black text-black" />
          </span>
        </div>
        {!isUpcoming && !isLive && !isYouTube && duration !== "00:00" && (
          <div className="absolute right-2 bottom-2 rounded border border-white/10 bg-black/70 px-1.5 py-0.5 text-[10px] font-medium text-white backdrop-blur-sm">
            {duration}
          </div>
        )}
      </div>
      <div className="flex flex-1 flex-col justify-center bg-[#121212] p-3 transition-colors group-hover:bg-[#1a1a1a]">
        <h3 className="line-clamp-2 text-sm leading-snug font-medium text-gray-200">{item.title}</h3>
        {formattedDate && <div className="mt-2 text-[10px] font-medium tracking-wide text-stone-500">{formattedDate}</div>}
      </div>
    </button>
  );
}
