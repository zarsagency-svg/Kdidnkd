"use client";

import Link from "next/link";
import {
  AlertCircle,
  ArrowRight,
  Bookmark,
  Check,
  CheckCircle2,
  ChevronDown,
  ExternalLink,
  FolderOpen,
  History,
  LayoutGrid,
  Loader2,
  Plus,
  Search,
  Sparkles,
  X,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { BatchRecord } from "@/db/schema";

const ITEMS_PER_PAGE = 12;
const LOGO_URL = "https://i.ibb.co/yF4mhNPB/f493d534-fbf8-4b31-b741-83b343f8a9e1.jpg";

type TabName = "new" | "wishlist";

export function StudyBeeApp() {
  const [batches, setBatches] = useState<BatchRecord[]>([]);
  const [currentTab, setCurrentTab] = useState<TabName>("new");
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [visibleCount, setVisibleCount] = useState(ITEMS_PER_PAGE);
  const [isLoading, setIsLoading] = useState(true);
  const [loadFailed, setLoadFailed] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const loadMoreTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = useCallback((message: string) => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToastMessage(message);
    toastTimer.current = setTimeout(() => setToastMessage(null), 3000);
  }, []);

  useEffect(() => {
    let active = true;

    try {
      const stored = JSON.parse(localStorage.getItem("studybee_wishlist") || "[]") as unknown;
      if (Array.isArray(stored)) setWishlist(stored.map(String));
    } catch {
      localStorage.removeItem("studybee_wishlist");
    }

    async function fetchBatches() {
      try {
        const response = await fetch(`/api/batches?t=${Date.now()}`, { cache: "no-store" });
        if (!response.ok) throw new Error("Failed to load JSON");
        const data = (await response.json()) as { new?: BatchRecord[]; old?: BatchRecord[] };
        if (!active) return;
        setBatches([...(data.new || []), ...(data.old || [])]);
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching batches:", error);
        if (!active) return;
        setLoadFailed(true);
        setIsLoading(false);
      }
    }

    void fetchBatches();
    return () => {
      active = false;
      if (toastTimer.current) clearTimeout(toastTimer.current);
      if (loadMoreTimer.current) clearTimeout(loadMoreTimer.current);
    };
  }, []);

  const filteredBatches = useMemo(() => {
    const source = currentTab === "wishlist"
      ? Array.from(new Map(batches.map((batch) => [String(batch.id), batch])).values()).filter((batch) =>
          wishlist.includes(String(batch.id)),
        )
      : batches;
    const normalizedQuery = query.toLowerCase().trim();
    if (!normalizedQuery) return source;
    return source.filter(
      (batch) =>
        batch.title.toLowerCase().includes(normalizedQuery) || String(batch.id).includes(normalizedQuery),
    );
  }, [batches, currentTab, query, wishlist]);

  function switchTab(tabName: TabName) {
    setCurrentTab(tabName);
    setQuery("");
    setVisibleCount(ITEMS_PER_PAGE);
  }

  function updateQuery(value: string) {
    setQuery(value);
    setVisibleCount(ITEMS_PER_PAGE);
  }

  function clearSearch() {
    setQuery("");
    setVisibleCount(ITEMS_PER_PAGE);
    document.getElementById("searchInput")?.focus();
  }

  function toggleEnroll(batchId: number) {
    const id = String(batchId);
    const isEnrolled = wishlist.includes(id);
    const nextWishlist = isEnrolled ? wishlist.filter((item) => item !== id) : [...wishlist, id];
    setWishlist(nextWishlist);
    localStorage.setItem("studybee_wishlist", JSON.stringify(nextWishlist));
    if (!isEnrolled) showToast("Enrolled in batch!");
    if (isEnrolled && currentTab === "wishlist") setVisibleCount(ITEMS_PER_PAGE);
  }

  function loadMore() {
    if (isLoadingMore) return;
    setIsLoadingMore(true);
    loadMoreTimer.current = setTimeout(() => {
      setVisibleCount((count) => Math.min(count + ITEMS_PER_PAGE, filteredBatches.length));
      setIsLoadingMore(false);
    }, 300);
  }

  return (
    <>
      {toastMessage && (
        <div
          id="toast"
          role="status"
          className="toast-enter fixed top-6 left-1/2 z-[999] flex -translate-x-1/2 items-center gap-2.5 rounded-lg border border-green-800 bg-green-950/90 px-4 py-2.5 text-sm font-medium text-green-400"
        >
          <CheckCircle2 className="h-4 w-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      <nav className="nav-glass sticky top-0 z-40 h-[70px] w-full">
        <div className="mx-auto flex h-full max-w-[90rem] items-center justify-between px-4 sm:px-6">
          <button
            type="button"
            aria-label="Reload StudyBee"
            onClick={() => window.location.reload()}
            className="btn-click-effect flex cursor-pointer items-center gap-3"
          >
            <span className="relative z-10 flex h-9 w-9 items-center justify-center overflow-hidden rounded-lg border border-white/10 bg-black">
              {/* The original StudyBee asset, served directly from its source URL. */}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={LOGO_URL} alt="Logo" className="h-full w-full object-cover" />
            </span>
            <span className="font-syne text-xl font-black tracking-wider text-white">
              STUDY<span className="text-theme-yellow">BEE</span>
            </span>
          </button>

          <div className="hidden items-center gap-6 md:flex">
            <button
              type="button"
              onClick={() => switchTab("new")}
              className="btn-click-effect flex items-center gap-2 text-sm font-bold text-white transition-colors hover:text-theme-yellow"
            >
              <LayoutGrid className="h-4 w-4" /> Batches
            </button>
            <button
              type="button"
              onClick={() => switchTab("wishlist")}
              className="flex items-center gap-2 text-sm font-bold text-stone-400 transition-colors hover:text-white"
            >
              <Bookmark className="h-4 w-4" /> My Enrollments
            </button>
          </div>

          <div className="flex items-center gap-3 md:hidden">
            <button
              type="button"
              aria-label="My enrollments"
              onClick={() => switchTab("wishlist")}
              className="btn-click-effect relative rounded-lg border border-white/10 bg-white/5 p-2 text-stone-300 transition-colors hover:border-theme-yellow hover:text-theme-yellow"
            >
              <Bookmark className="h-5 w-5" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full bg-theme-green" />
              )}
            </button>
          </div>
        </div>
      </nav>

      <main className="relative z-10 mx-auto w-full max-w-[90rem] flex-1 px-4 pt-8 sm:px-6">
        <div
          className="fade-in-pop mb-8 flex flex-col items-start justify-between gap-4 md:flex-row md:items-center"
          style={{ animationDelay: "50ms" }}
        >
          <div className="hide-scroll flex w-full items-center gap-1 overflow-x-auto rounded-xl border border-white/5 bg-[#121212] p-1 shadow-inner sm:gap-2 md:w-auto">
            <button
              id="tab-new"
              type="button"
              onClick={() => switchTab("new")}
              className={`flex shrink-0 items-center gap-1.5 rounded-lg border px-3 py-1.5 text-[11px] font-bold transition-all sm:px-5 sm:py-2 sm:text-sm ${
                currentTab === "new"
                  ? "border-white/10 bg-white/10 text-white"
                  : "border-transparent bg-transparent text-stone-400 hover:text-stone-200"
              }`}
            >
              <Sparkles className="h-3.5 w-3.5 text-theme-yellow sm:h-4 sm:w-4" />
              Latest <span className="hidden sm:inline">Batches</span>
            </button>

            <button
              id="tab-wishlist"
              type="button"
              onClick={() => switchTab("wishlist")}
              className={`flex shrink-0 items-center gap-1.5 rounded-lg border px-3 py-1.5 text-[11px] font-bold transition-all sm:px-5 sm:py-2 sm:text-sm ${
                currentTab === "wishlist"
                  ? "border-white/10 bg-white/10 text-white"
                  : "border-transparent bg-transparent text-stone-400 hover:text-stone-200"
              }`}
            >
              <Bookmark className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
              <span className="hidden sm:inline">My </span>Enrolled
              {wishlist.length > 0 && (
                <span className="rounded bg-theme-green px-1.5 py-0.5 text-[9px] font-black text-black sm:text-[10px]">
                  {wishlist.length}
                </span>
              )}
            </button>

            <div className="mx-1 h-4 w-px shrink-0 bg-white/10" />

            <a
              href="https://old-nt.studybeepro.site"
              className="btn-click-effect flex shrink-0 items-center gap-1.5 rounded-lg border border-transparent bg-transparent px-3 py-1.5 text-[11px] font-bold text-stone-400 transition-all hover:text-theme-yellow sm:px-5 sm:py-2 sm:text-sm"
            >
              <History className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
              Old <span className="hidden sm:inline">Batches</span>
              <ExternalLink className="h-3 w-3 opacity-60" />
            </a>
          </div>

          <div className="relative w-full md:w-[350px]">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5">
              <Search className="h-4 w-4 text-stone-500" />
            </div>
            <input
              type="text"
              id="searchInput"
              value={query}
              onChange={(event) => updateQuery(event.target.value)}
              placeholder="Search batches..."
              className="block w-full rounded-lg border border-white/10 bg-[#121212] py-2.5 pr-10 pl-10 text-sm text-white transition-all placeholder:text-stone-600 focus:border-theme-yellow/50 focus:bg-[#1a1a1a] focus:outline-none"
            />
            {query.length > 0 && (
              <button
                id="clearSearchBtn"
                type="button"
                aria-label="Clear search"
                onClick={clearSearch}
                className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-stone-500 transition-colors hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        {isLoading && (
          <div id="loadingIndicator" className="flex flex-col items-center justify-center py-20">
            <Loader2 className="mb-3 h-8 w-8 animate-spin text-theme-yellow" />
            <p className="text-sm font-medium text-stone-400">Loading batches...</p>
          </div>
        )}

        {loadFailed && (
          <div id="loadingIndicator" className="flex flex-col items-center justify-center py-20">
            <div className="py-10 text-center">
              <AlertCircle className="mx-auto mb-2 h-8 w-8 text-stone-600" />
              <p className="text-sm font-medium text-stone-400">Failed to load batches</p>
            </div>
          </div>
        )}

        {!isLoading && !loadFailed && filteredBatches.length > 0 && (
          <div id="batchGrid" className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredBatches.slice(0, visibleCount).map((batch, index) => {
              const isEnrolled = wishlist.includes(String(batch.id));
              return (
                <div
                  key={batch.id}
                  className="premium-card fade-in-pop group relative flex flex-col overflow-hidden rounded-xl"
                  style={{ animationDelay: `${(index % ITEMS_PER_PAGE) * 30}ms` }}
                >
                  <div className="relative aspect-[16/9] w-full overflow-hidden border-b border-white/5 bg-black">
                    {/* Reference thumbnails are intentionally rendered from their original URLs. */}
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={batch.thumbnail}
                      alt={batch.title}
                      loading="lazy"
                      className="h-full w-full object-cover opacity-90 transition-transform duration-500 group-hover:scale-105 group-hover:opacity-100"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent opacity-90" />
                    <div className="absolute top-3 right-3 z-10 flex items-center justify-center rounded border border-theme-green/30 bg-theme-green/20 px-2 py-1 shadow-sm backdrop-blur-md">
                      <span className="text-[9px] font-black tracking-widest text-theme-green uppercase">FREE</span>
                    </div>
                  </div>

                  <div className="relative z-20 flex flex-1 flex-col p-5">
                    <h3 className="mb-4 line-clamp-2 text-sm leading-relaxed font-semibold text-gray-200 transition-colors group-hover:text-white">
                      {batch.title}
                    </h3>
                    <div className="mt-auto flex items-center justify-between border-t border-white/5 pt-4">
                      <div>
                        <button
                          type="button"
                          onClick={() => toggleEnroll(batch.id)}
                          className={isEnrolled
                            ? "flex items-center gap-1.5 rounded border border-theme-green/20 bg-theme-green/10 px-3 py-1.5 text-[11px] font-bold tracking-wider text-theme-green transition-colors hover:bg-theme-green/20"
                            : "btn-click-effect flex items-center gap-1.5 rounded bg-theme-green px-3 py-1.5 text-[11px] font-bold tracking-wider text-black shadow-md transition-colors hover:bg-emerald-400"}
                        >
                          {isEnrolled ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
                          {isEnrolled ? "ENROLLED" : "ENROLL"}
                        </button>
                      </div>
                      <Link
                        href={`/batch.html?id=${batch.id}`}
                        className="btn-click-effect flex items-center gap-1.5 rounded bg-theme-yellow px-4 py-2 text-[11px] font-bold tracking-wider text-black uppercase shadow-md transition-colors hover:bg-yellow-400"
                      >
                        Let&apos;s Study <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {!isLoading && !loadFailed && visibleCount < filteredBatches.length && (
          <div id="loadMoreContainer" className="fade-in-pop mt-10 mb-6 flex w-full justify-center">
            <button
              id="loadMoreBtn"
              type="button"
              disabled={isLoadingMore}
              onClick={loadMore}
              className="btn-click-effect flex items-center gap-2 rounded-lg border border-white/10 bg-[#121212] px-8 py-2.5 text-sm font-semibold text-white transition-all hover:border-white/30"
            >
              {isLoadingMore ? (
                <><Loader2 className="h-4 w-4 animate-spin text-stone-400" /> Loading</>
              ) : (
                <>Load More <ChevronDown className="h-4 w-4" /></>
              )}
            </button>
          </div>
        )}

        {!isLoading && !loadFailed && filteredBatches.length === 0 && (
          <div id="emptyState" className="fade-in-pop flex flex-col items-center justify-center py-20 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-white/5 bg-white/5">
              <FolderOpen className="h-8 w-8 text-stone-600" />
            </div>
            <h3 className="mb-1 text-xl font-bold text-white">No Batches Found</h3>
            <p className="text-sm text-stone-500">Try adjusting your search or enrolling in new batches.</p>
          </div>
        )}
      </main>
    </>
  );
}
